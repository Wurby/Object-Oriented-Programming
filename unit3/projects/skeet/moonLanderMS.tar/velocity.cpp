/*************************************************************
 * File: velocity.cpp
 * Author: Joshua Pearson
 *
 * Summary: 
 *************************************************************/

#include "velocity.h"

Velocity::Velocity()
{
}
Velocity::Velocity(const float &, const float &)
{
}