/*************************************************************
 * File: velocity.cpp
 * Author: Joshua Pearson
 *
 * Summary: Doesn't do anything... Yet.
 *************************************************************/

#include "velocity.h"

Velocity::Velocity()
{
}
Velocity::Velocity(const float &, const float &)
{
}