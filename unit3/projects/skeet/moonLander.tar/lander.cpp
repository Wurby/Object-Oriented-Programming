/*************************************************************
 * File: lander.cpp
 * Author: Joshua Pearson
 *
 * Summary: Doesn't do anything... Yet.
 *************************************************************/

#include "lander.h"

void Lander::applyGravity(float)
{
}
void Lander::applyThrustLeft()
{
}
void Lander::applyThrustRight()
{
}
void Lander::applyThrustBottom()
{
}
void Lander::advance()
{
}
void Lander::draw()
{
    drawLander(point);
}